# ContextFlow — Fix & Re-deploy Plan

## Steps
- [x] 1. Fix Vercel file-upload crash: switch multer to memoryStorage in server.js
- [x] 2. Rename all "Talking Rabbitt" / "rabbitt" references to "ContextFlow"
   - [x] package.json (name + description)
   - [x] server.js (health msg, prompt, console.log, upload buffer)
   - [x] public/app.js (comment + footer text)
   - [x] public/styles.css (comment)
   - [x] TODO.md
   - [x] Bhavya.md
   - [x] README.md
- [ ] 4. Re-deploy to Vercel (`vercel --prod`)

